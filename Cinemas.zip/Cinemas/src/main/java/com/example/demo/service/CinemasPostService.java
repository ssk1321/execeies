package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.RetentionUser;

public interface CinemasPostService {
	/**
	 * cinema_postテーブルから全てのユーザー投稿を取得する
	 * @Param なし
	 * @return Iterable<CinemasPost>
	 */
	
	List<RetentionUser> findAllPost();
	
	/**
	 * 新しい投稿内容をDBに保存する
	 * @Param RetentionUser
	 * @return boolean
	 */
	
	boolean createNewPost(RetentionUser retentionUser);
	
	/**
	 * cinema_postテーブルからユーザー自身の投稿内容だけを全て取得する
	 * @Param String user_id
	 * @return Iterable<CinemasPost>
	 */
	List<RetentionUser> findPostsBySelf(String user_id);
	
	/**
	 * ユーザー自身が投稿したものを削除する
	 * @Param Integer postId, String userId
	 * @return int
	 */
	public int deletePost(Integer postId, String userId);
}
